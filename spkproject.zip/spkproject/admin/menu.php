<div align="right" class="links_menu" id="menu">
	<a href="index.php"><i class="fa fa-home"></i>Home</a> | 
	<a href="mahasiswa.php"><i class="fa fa-users"></i>Mahasiswa</a> | 
	<a href="kriteria.php"><i class="fa fa-bar-chart-o"></i>Kriteria</a> | 
	<a href="himpunan.php"><i class="fa fa-bookmark"></i>Himpunan Kriteria</a> | 
	<a href="klasifikasi.php"><i class="fa fa-tag"></i>Klasifikasi</a>
	<a href="analisa.php"><i class="fa fa-pencil"></i> Analisa</a>
	<!-- <a href="logout.php"><i class="fa fa-times"></i> Logout</a> -->
 </div>
		