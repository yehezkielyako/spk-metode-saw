<!-- Footer -->
<div class="footer">
		<b>&copy; Copyright <?php echo date("Y") ?>. | Sistem Penunjang Keputusan</b>
			</div>
		</div>
	</div>
</div>
        
</body>
</html>
