// JavaScript Document
$(document).ready(function(){
	$("#awal").datepicker({
			dateFormat:"yy-mm-dd"        
    });
	$("#akhir").datepicker({
			dateFormat:"yy-mm-dd"        
    });
});